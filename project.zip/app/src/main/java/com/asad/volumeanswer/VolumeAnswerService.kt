package com.asad.volumeanswer

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.SystemClock
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class VolumeAnswerService : AccessibilityService() {

    private var lastDownTime = 0L
    private var answered = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private fun isRinging(): Boolean {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            if (tm.callState == TelephonyManager.CALL_STATE_RINGING) return true
        } catch (e: Exception) {
        }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.mode == AudioManager.MODE_RINGTONE
    }

    private fun log(msg: String) {
        getSharedPreferences("log", Context.MODE_PRIVATE).edit().putString("last", msg).apply()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }
        val ringing = isRinging()
        if (event.action == KeyEvent.ACTION_DOWN) {
            log("ভলিউম বাটন ধরা পড়েছে, কল বাজছে: " + (if (ringing) "হ্যাঁ" else "না") +
                ", repeat=" + event.repeatCount)
        }
        if (!ringing) {
            answered = false
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (answered) return true
            val now = SystemClock.elapsedRealtime()
            val longPress = event.repeatCount >= 1 || event.isLongPress
            val doublePress = event.repeatCount == 0 && (now - lastDownTime) in 1..800
            if (event.repeatCount == 0) lastDownTime = now
            if (longPress || doublePress) {
                answered = true
                answerCall()
            }
        }
        return true
    }

    private fun answerCall() {
        if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            log("ANSWER_PHONE_CALLS পারমিশন নেই")
            return
        }
        try {
            val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            log("acceptRingingCall() চালানো হয়েছে")
        } catch (e: Exception) {
            log("এরর: " + e.message)
        }
    }
}

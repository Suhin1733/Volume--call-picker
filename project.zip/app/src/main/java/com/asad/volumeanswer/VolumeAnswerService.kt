package com.asad.volumeanswer

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.SystemClock
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VolumeAnswerService : AccessibilityService() {

    private var lastDownTime = 0L
    private var answered = false
    @Volatile private var ringingFlag = false

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val st = intent?.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            ringingFlag = (st == TelephonyManager.EXTRA_STATE_RINGING)
            if (st != TelephonyManager.EXTRA_STATE_RINGING) answered = false
            log("কল স্টেট: $st")
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            registerReceiver(phoneReceiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
        } catch (e: Exception) {
            log("receiver এরর: " + e.message)
        }
        log("সার্ভিস চালু হয়েছে")
    }

    override fun onDestroy() {
        try { unregisterReceiver(phoneReceiver) } catch (e: Exception) {}
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private fun callStateRinging(): Boolean {
        return try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            @Suppress("DEPRECATION")
            tm.callState == TelephonyManager.CALL_STATE_RINGING
        } catch (e: Exception) {
            false
        }
    }

    private fun audioModeRinging(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.mode == AudioManager.MODE_RINGTONE
    }

    private fun log(msg: String) {
        val sp = getSharedPreferences("log", Context.MODE_PRIVATE)
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val old = (sp.getString("last", "") ?: "").split("\n").filter { it.isNotBlank() }
        val all = (old + "$t $msg").takeLast(6)
        sp.edit().putString("last", all.joinToString("\n")).apply()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }
        val a = ringingFlag
        val b = callStateRinging()
        val c = audioModeRinging()
        val ringing = a || b || c
        if (event.action == KeyEvent.ACTION_DOWN && (ringing || event.repeatCount == 0)) {
            log("বাটন: receiver=$a callState=$b audio=$c repeat=${event.repeatCount}")
        }
        if (!ringing) return false

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (answered) return true
            val now = SystemClock.elapsedRealtime()
            val longPress = event.repeatCount >= 1 || event.isLongPress
            val doublePress = event.repeatCount == 0 && (now - lastDownTime) in 1..800
            if (event.repeatCount == 0) lastDownTime = now
            if (longPress || doublePress) {
                answered = true
                answerCall()
            }
        }
        return true
    }

    private fun answerCall() {
        if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            log("ANSWER_PHONE_CALLS পারমিশন নেই")
            return
        }
        try {
            val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            log("acceptRingingCall() চালানো হয়েছে")
        } catch (e: Exception) {
            log("এরর: " + e.message)
        }
    }
}

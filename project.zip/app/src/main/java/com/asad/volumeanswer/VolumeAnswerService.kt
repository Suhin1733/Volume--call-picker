package com.asad.volumeanswer

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.SystemClock
import android.telecom.TelecomManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VolumeAnswerService : AccessibilityService() {

    private var lastDownTime = 0L
    private var answered = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private fun isRinging(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.mode == AudioManager.MODE_RINGTONE
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }
        if (!isRinging()) {
            answered = false
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (answered) return true
            val now = SystemClock.elapsedRealtime()
            val longPress = event.repeatCount >= 1 || event.isLongPress
            val doublePress = event.repeatCount == 0 && (now - lastDownTime) in 1..600
            if (event.repeatCount == 0) lastDownTime = now
            if (longPress || doublePress) {
                answered = true
                answerCall()
            }
        }
        // Ringing অবস্থায় ভলিউম বাটনের ইভেন্ট আটকে দেওয়া হচ্ছে
        return true
    }

    private fun answerCall() {
        if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

package com.asad.volumeanswer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        root.addView(TextView(this).apply {
            text = "Volume Answer"
            textSize = 26f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        })

        root.addView(TextView(this).apply {
            text = "কল আসলে ভলিউম বাটন ডাবল প্রেস বা লং প্রেস করলে কল রিসিভ হবে।\n\n" +
                "ব্যবহারের জন্য নিচের দুটি ধাপ করুন।"
            textSize = 16f
            setPadding(0, pad, 0, pad)
        })

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "১. কল রিসিভের পারমিশন দিন"
            setOnClickListener {
                requestPermissions(arrayOf(Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_PHONE_STATE), 1)
            }
        })

        root.addView(Button(this).apply {
            text = "২. Accessibility সার্ভিস চালু করুন"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "৩. অ্যাপ সেটিংস (Autostart / ব্যাটারি)"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(android.net.Uri.parse("package:$packageName"))
                )
            }
        })

        root.addView(TextView(this).apply {
            text = "\nRedmi (MIUI) ফোনে অবশ্যই:\n" +
                "• অ্যাপ সেটিংস > Autostart চালু করুন\n" +
                "• Battery saver > No restrictions দিন\n" +
                "• Recent apps-এ অ্যাপটি লক করে রাখুন\n\n" +
                "Accessibility তে Downloaded apps > Volume Answer খুলে চালু করুন।"
            textSize = 14f
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    private fun refreshStatus() {
        val perm = checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) ==
            PackageManager.PERMISSION_GRANTED
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?.contains(packageName) == true
        status.text = "পারমিশন: " + (if (perm) "✅ দেওয়া আছে" else "❌ বাকি") +
            "\nAccessibility: " + (if (enabled) "✅ চালু" else "❌ বন্ধ") +
            "\n\nশেষ ঘটনা: " + getSharedPreferences("log", MODE_PRIVATE).getString("last", "কিছু ধরা পড়েনি") + "\n"
    }
}
